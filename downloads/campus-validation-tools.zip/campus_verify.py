"""Read-only, evidence-based PC verifier. Missing evidence is never a pass."""
import argparse
import base64
import datetime
import getpass
import html
import json
import os
from pathlib import Path
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid

if __package__:
    from .vbox_inventory import ReadOnlyVBox, parse_inventory, machine_fields
else:
    from collect_virtualbox import ReadOnlyVBox, parse_inventory, machine_fields


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None


class GNS3:
    def __init__(self,url,auth=None):
        p=urllib.parse.urlsplit(url)
        if p.scheme not in ('http','https') or p.hostname not in ('localhost','127.0.0.1','::1') or p.username or p.password or p.query or p.fragment:
            raise ValueError('Use a local GNS3 URL without credentials or query parameters')
        self.url=url.rstrip('/');self.auth=auth
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    def get(self,path):
        request=urllib.request.Request(self.url+'/v2'+path)
        if self.auth:
            request.add_header('Authorization','Basic '+base64.b64encode((self.auth[0]+':'+self.auth[1]).encode()).decode())
        with self.opener.open(request,timeout=5) as response:
            body=response.read(4*1024*1024+1)
            if len(body)>4*1024*1024:raise ValueError('Unexpectedly large GNS3 response')
            return json.loads(body)


def fresh_guest(report,role,project_id,hardware,now=None):
    if report.get('role')!=role or report.get('project_id')!=project_id:
        return False,'Guest evidence does not match this role/project'
    try:
        actual=uuid.UUID(report['hardware_uuid']);expected=uuid.UUID(hardware)
        if expected not in (actual,uuid.UUID(bytes_le=actual.bytes)):
            return False,'Guest hardware UUID does not match the selected VM'
        stamp=datetime.datetime.fromisoformat(report['collected_at'])
        now=now or datetime.datetime.now(datetime.timezone.utc)
        age=(now-stamp).total_seconds()
        if age < -300 or age > 3600:return False,'Guest evidence is stale or guest clock is incorrect'
    except (ValueError,KeyError,TypeError):return False,'Missing or invalid guest identity/time evidence'
    return True,'Matched role, project, hardware UUID and recent timestamp'


def endpoint_set(link):
    return frozenset((e['node_id'],e['adapter_number'],e['port_number']) for e in link['nodes'])


def normalized_ports(node):
    return sorted((p['port_number'],p['type'],p.get('vlan',1)) for p in node['properties']['ports_mapping'])


def outcome(checks):
    required=[c for c in checks if c['required']]
    if any(c['status']=='failed' for c in required):return 'failed'
    if not required or any(c['status'] in ('blocked','not_run') for c in required):return 'incomplete'
    return 'passed'


def host_memory_mb():
    if os.name == 'nt':
        import ctypes
        class MemoryStatus(ctypes.Structure):
            _fields_ = [('length',ctypes.c_ulong),('load',ctypes.c_ulong),
                ('total_physical',ctypes.c_ulonglong),('available_physical',ctypes.c_ulonglong),
                ('total_page',ctypes.c_ulonglong),('available_page',ctypes.c_ulonglong),
                ('total_virtual',ctypes.c_ulonglong),('available_virtual',ctypes.c_ulonglong),
                ('available_extended',ctypes.c_ulonglong)]
        memory=MemoryStatus();memory.length=ctypes.sizeof(memory)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
            raise OSError('Cannot read host RAM')
        return memory.total_physical//1024**2,memory.available_physical//1024**2
    page=os.sysconf('SC_PAGE_SIZE')
    return os.sysconf('SC_PHYS_PAGES')*page//1024**2,os.sysconf('SC_AVPHYS_PAGES')*page//1024**2


def verify(directory,vbox=None,api=None,scope='all'):
    directory=Path(directory)
    plan=json.loads((directory/'campus-bindings.json').read_text(encoding='utf-8'))
    document=json.loads((directory/'Campus-XDR-existing.gns3').read_text(encoding='utf-8'))
    if plan.get('mode')!='reuse-existing-vms' or document['project_id']!=plan['project_id']:
        raise ValueError('Mismatched existing-VM campus package')
    uuid.UUID(plan['project_id'])
    roles={b['role']:b for b in plan['bindings']};machines={m['name']:m for m in plan['machines']}
    selected=set(roles) if scope=='all' else set(plan['profiles'][scope])
    checks=[]
    def add(name,status,evidence,role=None,required=True):
        checks.append({'check':name,'status':status,'role':role,'required':required,'evidence':evidence})
    add('file.project_identity','passed','Project ID matches binding manifest')
    vm_nodes={n['name']:n for n in document['topology']['nodes'] if n['node_type']=='virtualbox'}
    names=[b['vm_name'] for b in roles.values()];ids=[b['vm_uuid'] for b in roles.values()]
    good=len(names)==len(set(names)) and len(ids)==len(set(ids)) and not set(names)&set(plan['original_bases_excluded'])
    good=good and set(vm_nodes)==set(roles) and document.get('auto_start') is False
    good=good and all(vm_nodes[r]['properties']['vmname']==b['vm_name'] and vm_nodes[r]['properties'].get('linked_clone') is False for r,b in roles.items())
    add('file.existing_vm_bindings','passed' if good else 'failed','Unique existing VM bindings, excluded originals, linked_clone=false and auto_start=false checked')
    ram=sum(machines[r]['memory_mb'] for r in selected)
    add('resources.selected_guest_memory','passed',f'{scope}: {len(selected)} VMs; configured guest RAM {ram/1024:.1f} GiB plus host overhead. No VMs are started.',required=False)
    try:
        total,available=host_memory_mb()
        add('resources.host_ram','passed',f'Host total {total/1024:.1f} GiB, currently available {available/1024:.1f} GiB. Full configured scope needs {ram/1024:.1f} GiB plus host overhead; stage testing if needed.',required=False)
    except (OSError,ValueError,AttributeError):add('resources.host_ram','blocked','Host memory could not be queried',required=False)
    live_info={};registration={}
    try:
        vbox=vbox or ReadOnlyVBox()
        registration={r['uuid']:r['name'] for r in parse_inventory(vbox.run('list','vms'))}
        add('pc.virtualbox_inventory','passed',str(len(registration))+' registered VMs queried read-only')
    except (RuntimeError,ValueError,OSError) as exc:add('pc.virtualbox_inventory','blocked',str(exc));vbox=None
    for role,binding in roles.items():
        needed=role in selected
        if vbox is None:
            add('vm.registration','blocked','VirtualBox inventory unavailable',role,needed);continue
        if registration.get(binding['vm_uuid'])!=binding['vm_name']:
            add('vm.registration','failed','Name/UUID is absent or changed',role,needed);continue
        add('vm.registration','passed','Exact existing name and UUID match',role,needed)
        try:
            info=machine_fields(vbox.run('showvminfo',binding['vm_uuid'],'--machinereadable'));live_info[role]=info
            state=info.get('VMState','unknown')
            add('vm.running','passed' if state=='running' else 'blocked','Actual VirtualBox state: '+state,role,needed)
            # Registration metadata alone cannot prove the service is running inside the guest.
            value=info.get('GuestAdditionsVersion') or info.get('GuestAdditionsRunLevel')
            add('vm.guest_additions_metadata','passed' if value else 'blocked',str(value) if value else 'No Guest Additions evidence in current metadata; not proof it is uninstalled',role,False)
        except (RuntimeError,ValueError,OSError) as exc:add('vm.running','blocked',str(exc),role,needed)
    api=api or GNS3('http://127.0.0.1:3080')
    try:
        version=api.get('/version');add('gns3.api','passed','GNS3 version '+str(version.get('version','unknown')))
        pid=plan['project_id'];live_nodes=api.get('/projects/'+pid+'/nodes');live_links=api.get('/projects/'+pid+'/links')
        by_id={n['node_id']:n for n in live_nodes}
        expected=document['topology']['nodes']
        matches=set(by_id)=={n['node_id'] for n in expected}
        for node in expected:
            live=by_id.get(node['node_id'])
            if live is None:matches=False;continue
            if live.get('node_type')!=node['node_type']:matches=False
            if node['node_type']=='virtualbox':
                matches=matches and live.get('properties',{}).get('vmname')==node['properties']['vmname'] and live.get('properties',{}).get('linked_clone') is False
            else:matches=matches and normalized_ports(live)==normalized_ports(node)
        add('gns3.nodes_and_vlan_ports','passed' if matches else 'failed','Actual loaded project node identities, VM bindings and access/trunk VLAN mappings compared')
        link_match={endpoint_set(l) for l in live_links}=={endpoint_set(l) for l in document['topology']['links']}
        add('gns3.links','passed' if link_match else 'failed','Actual loaded project endpoint wiring compared')
    except (RuntimeError,ValueError,OSError,KeyError,urllib.error.URLError) as exc:
        add('gns3.loaded_project','blocked','Cannot verify the opened local project: '+str(exc))
    router_ids={'CORE1':'10.255.255.1','CORE2':'10.255.255.2','DIST-A':'10.255.255.11','DIST-B':'10.255.255.12'}
    required_neighbors={r:{router_ids[x] for x in selected if x.startswith('DIST' if r.startswith('CORE') else 'CORE')}
                        for r in router_ids}
    for role in roles:
        if role not in selected:
            add('guest.functional_checks','not_run','Outside the explicitly selected scope',role,False);continue
        path=directory/'guest-results'/(role+'.json')
        if not path.exists():
            add('guest.evidence','blocked','No guest report. IP/OSPF/VRRP/firewall/sensor state cannot be inferred from a powered-off VM or drawing.',role);continue
        try:guest=json.loads(path.read_text(encoding='utf-8-sig'))
        except (ValueError,OSError):
            add('guest.evidence','blocked','Guest report is unreadable or malformed',role);continue
        expected_hw=live_info.get(role,{}).get('hardwareuuid') or roles[role]['vm_uuid']
        valid,reason=fresh_guest(guest,role,plan['project_id'],expected_hw)
        add('guest.identity_and_freshness','passed' if valid else 'blocked',reason,role)
        if not valid:continue
        commands=guest.get('commands',{})
        def cmd(name):return commands.get(name,{'exit_code':127,'stdout':'','stderr':'no command result'})
        addresses=cmd('addresses');links=cmd('links');expected_ifaces={}
        info=live_info.get(role,{})
        try:
            actual_addresses=json.loads(addresses['stdout']);actual_links=json.loads(links['stdout'])
            interfaces={str(i.get('address','')).replace(':','').lower():i['ifname'] for i in actual_links}
            expected_ifaces={}
            for i in machines[role]['interfaces']:
                mac=info.get('macaddress'+str(i['port']+1),'').lower()
                if not mac or mac not in interfaces:raise ValueError('Cannot map VirtualBox adapter to guest interface by MAC')
                name=interfaces[mac]+('.'+str(i['vlan']) if 'vlan' in i else '')
                expected_ifaces[i['port'],i.get('vlan')]=name
                if not i.get('cidr'):continue
                if role in ('FW1','FW2'):
                    continue  # HA cluster address ownership cannot be inferred from ordinary IP fields.
                address,prefix=i['cidr'].split('/')
                present=any(a['ifname']==name and any(v.get('local')==address and v.get('prefixlen')==int(prefix) for v in a.get('addr_info',[])) for a in actual_addresses)
                add('guest.ip_address','passed' if present else 'failed',f'{name}: expected {i["cidr"]}',role)
        except (ValueError,KeyError,TypeError):
            add('guest.ip_address','blocked','Missing address/link data or MAC-to-interface mapping',role)
        if role in required_neighbors:
            result=cmd('ospf_neighbors')
            if result['exit_code']:
                add('router.ospf_neighbors','failed' if result['exit_code']==127 else 'blocked','vtysh missing or neighbor query unavailable',role)
            else:
                try:
                    value=json.loads(result['stdout'])
                    full={rid for rid,entries in value['neighbors'].items() if any(n.get('nbrState','').startswith('Full') for n in entries)}
                    add('router.ospf_neighbors','passed' if required_neighbors[role]<=full else 'failed',f'Full router IDs: {sorted(full)}; required {sorted(required_neighbors[role])}',role)
                except (ValueError,KeyError,TypeError):add('router.ospf_neighbors','blocked','Unrecognized FRR neighbor output',role)
            routes=cmd('ospf_routes')
            networks=[]
            for distribution,subnets in [('DIST-A',['10.10.10.0/24','10.10.20.0/24','10.10.30.0/24']),('DIST-B',['10.20.40.0/24','10.20.50.0/24','10.20.60.0/24'])]:
                if distribution in selected and distribution!=role:networks.extend(subnets)
            if role.startswith('DIST'):networks.extend(['10.80.0.0/24','0.0.0.0/0'])
            try:
                table=json.loads(routes['stdout'])
                kernel=cmd('routes')
                actual_kernel=json.loads(kernel['stdout'])
                installed={r.get('dst') for r in actual_kernel}
                missing=[prefix for prefix in networks if not table.get(prefix) or ('default' if prefix=='0.0.0.0/0' else prefix) not in installed]
                add('router.ospf_routes','passed' if not missing and routes['exit_code']==0 and kernel['exit_code']==0 else 'failed','Missing OSPF/kernel route prefixes: '+str(missing),role)
            except (ValueError,KeyError,TypeError):add('router.ospf_routes','blocked','No readable OSPF route evidence',role)
            forwarding=cmd('forwarding')
            add('router.ip_forwarding','passed' if forwarding['exit_code']==0 and forwarding['stdout'].strip()=='1' else 'failed','IPv4 forwarding must equal 1',role)
        if role.startswith('CORE'):
            result=cmd('keepalived')
            add('router.keepalived','passed' if result['exit_code']==0 and result['stdout'].strip()=='active' else 'failed','Service must be active; this alone does not validate VRRP takeover',role)
            add('router.vrrp_failover','not_run','Requires baseline plus controlled failure and restoration observations',role)
        if role in ('ZEEK-SENSOR','SURICATA-SENSOR'):
            bridge=cmd('bridge')
            try:
                value=json.loads(bridge['stdout']);masters={i['master'] for i in value if i.get('master') is not None}
                names={i['ifname'] for i in value}
                data_names={expected_ifaces[(i,None)] for i in (0,1)}
                good=bridge['exit_code']==0 and data_names<=names and any(sum(i.get('master')==m and i['ifname'] in data_names for i in value)==2 for m in masters)
                add('sensor.inline_bridge','passed' if good else 'failed','Both data ports must share a transparent bridge',role)
            except (ValueError,KeyError,TypeError,UnboundLocalError):add('sensor.inline_bridge','blocked','Cannot verify bridge membership',role)
            running=cmd('sensor_process')['exit_code']==0 or cmd('sensor_process_alt')['exit_code']==0
            add('sensor.process','passed' if running else 'failed','Expected sensor process must be running',role)
            add('sensor.actual_traffic_logs','not_run','Needs timestamped Zeek/Suricata events correlated with a controlled test; process existence is insufficient',role)
        if role in ('FW1','FW2'):
            add('firewall.policy_and_ha','not_run','Requires vendor HA status, permit/deny traffic controls and failover/restore evidence',role)
        tests=guest.get('active_tests',{})
        if role not in ('LEGACY-WIN7','PFSENSE-SANDBOX'):
            result=tests.get('dmz_http')
            if result is None:add('traffic.dmz_http','not_run','No active HTTP probe was requested',role)
            else:add('traffic.dmz_http','passed' if result.get('exit_code')==0 and re.fullmatch(r'[23]\d\d',result.get('stdout','').strip()) else 'failed','Actual HTTP response code: '+str(result.get('stdout','')).strip(),role)
        if role=='XDR-COLLECTOR':add('xdr.correlation_response','not_run','Requires network+authentication evidence, incident correlation, response application, rollback and normal-user control',role)
    for name,evidence in [
       ('scenario.core_failover_restore','Controlled core failure, VIP takeover, continuous traffic and restoration have not been exercised by this read-only tool.'),
       ('scenario.firewall_ha_restore','Vendor HA status and controlled firewall failover/restore evidence are required.'),
       ('scenario.firewall_allow_deny','Matched positive controls, denied traffic and relevant rule counters are required; an unreachable service alone is not proof of a block.'),
       ('scenario.sensor_log_delivery','Fresh controlled traffic must appear in the expected Zeek/Suricata logs and reach the collector.'),
       ('scenario.xdr_detect_respond_rollback','Requires a correlated incident, actual scoped action, attacker block, unaffected normal client and rollback evidence.')]:
        add(name,'not_run',evidence)
    return {'schema_version':1,'project_id':plan['project_id'],'scope':scope,'selected_roles':sorted(selected),
            'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':outcome(checks),'checks':checks,
            'note':'No VM was started, cloned, paused, stopped or configured. Missing evidence is not a pass. Cloud Docker results do not validate this PC campus.'}


def save_report(report,directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    (directory/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    rows=''.join('<tr><td>'+html.escape(str(c['role'] or 'PC/project'))+'</td><td>'+html.escape(c['check'])+'</td><td class="'+c['status']+'">'+c['status']+'</td><td>'+html.escape(c['evidence'])+'</td></tr>' for c in report['checks'])
    content='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>캠퍼스 실제 검증 결과</title><style>body{font:14px/1.6 system-ui;background:#0c1727;color:#e7effb;margin:30px}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #35465e;text-align:left}.passed{color:#71ddbb}.failed{color:#ff8b8b}.blocked,.not_run{color:#e9bf78}p{color:#b6c9dd}</style><h1>캠퍼스 실제 검증 결과</h1>'''
    content+='<p>전체 상태: '+html.escape(report['status'])+' · 범위: '+html.escape(report['scope'])+' · '+html.escape(report['collected_at'])+'</p>'
    content+='<p>passed=증거로 통과 · failed=실제 불일치 · blocked=접근/증거 부족 · not_run=미실행. 미실행을 통과로 계산하지 않습니다.</p>'
    content+='<table><tr><th>대상</th><th>항목</th><th>결과</th><th>근거</th></tr>'+rows+'</table></html>'
    (directory/'verification.html').write_text(content,encoding='utf-8')
    return directory


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',default=str(Path(__file__).resolve().parent))
    parser.add_argument('--url',default='http://127.0.0.1:3080');parser.add_argument('--scope',default='all')
    parser.add_argument('--auth',action='store_true',help='Prompt locally for GNS3 credentials; never saved in report')
    args=parser.parse_args();auth=(input('Local GNS3 username: '),getpass.getpass('Local GNS3 password: ')) if args.auth else None
    try:
        report=verify(args.directory,api=GNS3(args.url,auth),scope=args.scope)
        output=Path(args.directory)/('verification-results-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:5])
        save_report(report,output)
        print('Result: '+report['status']+'; '+str(output.resolve()),flush=True)
        print('Share verification.json. Open verification.html to inspect every blocked/failed check.',flush=True)
        return 0 if report['status']=='passed' else 2
    except (RuntimeError,ValueError,KeyError,OSError) as exc:print('STOP: '+str(exc),file=sys.stderr);return 1


if __name__=='__main__':raise SystemExit(main())
