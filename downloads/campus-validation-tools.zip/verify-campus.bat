@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python campus_verify.py > verification-run.txt 2>&1) else (py -3 campus_verify.py > verification-run.txt 2>&1)
set "campus_verify_exit=%errorlevel%"
type verification-run.txt
echo.
if "%campus_verify_exit%"=="2" echo INCOMPLETE means missing or failed evidence, not a successful full verification.
echo Results remain in verification-results-* after this window closes.
pause
exit /b %campus_verify_exit%
