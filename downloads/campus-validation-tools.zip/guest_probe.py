"""Collect bounded, read-only Linux guest evidence; never changes configuration."""
import argparse
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import uuid


def run(args,timeout=12):
    if not shutil.which(args[0]):return {'exit_code':127,'stdout':'','stderr':'command not installed'}
    try:
        r=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        return {'exit_code':r.returncode,'stdout':r.stdout[:131072],'stderr':r.stderr[:2048]}
    except subprocess.TimeoutExpired:return {'exit_code':124,'stdout':'','stderr':'command timed out'}


def probe(role,project_id,active=False):
    if not re.fullmatch(r'[A-Z0-9-]+',role):raise ValueError('Invalid role')
    project_id=str(uuid.UUID(project_id))
    product=Path('/sys/class/dmi/id/product_uuid')
    try: hardware_uuid=product.read_text().strip() if product.exists() else None
    except OSError: hardware_uuid=None
    result={'schema_version':1,'role':role,'project_id':project_id,
            'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'hardware_uuid':hardware_uuid,
            'hostname':socket.gethostname(),'uid':os.geteuid(),'commands':{},'active_tests':{}}
    commands={'addresses':['ip','-j','address'],'links':['ip','-j','link'],
              'routes':['ip','-j','route','show','table','main'],
              'bridge':['bridge','-j','link'],
              'forwarding':['sysctl','-n','net.ipv4.ip_forward']}
    if role.startswith(('CORE','DIST')):
        commands.update(frr_version=['vtysh','-c','show version'],ospf_neighbors=['vtysh','-c','show ip ospf neighbor json'],
                        ospf_routes=['vtysh','-c','show ip route ospf json'])
    if role.startswith('CORE'):commands['keepalived']=['systemctl','is-active','keepalived']
    if role=='ZEEK-SENSOR':commands['sensor_process']=['pgrep','-x','zeek']
    if role=='SURICATA-SENSOR':commands['sensor_process']=['pgrep','-x','Suricata-Main']
    if role=='SURICATA-SENSOR':commands['sensor_process_alt']=['pgrep','-x','suricata']
    for name,command in commands.items():result['commands'][name]=run(command)
    if active:
        # Only bounded service checks against this package's owned lab address plan.
        if role not in ('LEGACY-WIN7','PFSENSE-SANDBOX'):
            result['active_tests']['dmz_http']=run(['curl','--noproxy','*','--silent','--show-error','--output','/dev/null',
               '--write-out','%{http_code}','--max-time','4','http://10.90.0.10/'],6)
        if role.startswith(('STUDENT','FACULTY','ADMIN','RESEARCH','GUEST','IT')):
            result['active_tests']['server_ping']=run(['ping','-c','2','-W','1','10.80.0.20'],5)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role',required=True);parser.add_argument('--project-id',required=True)
    parser.add_argument('--active-tests',action='store_true');parser.add_argument('--output')
    args=parser.parse_args();result=probe(args.role,args.project_id,args.active_tests)
    text=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:
        with Path(args.output).open('x',encoding='utf-8') as out:out.write(text)
    else:print(text)


if __name__=='__main__':main()
