@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python campus_verify.py --auth) else (py -3 campus_verify.py --auth)
set "campus_verify_exit=%errorlevel%"
pause
exit /b %campus_verify_exit%
