@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python prepare_virtualbox.py --clone) else (py -3 prepare_virtualbox.py --clone)
echo.
pause
