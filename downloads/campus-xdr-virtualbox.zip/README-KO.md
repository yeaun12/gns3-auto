# VirtualBox 캠퍼스 XDR 프로젝트 — CXDR-bead2c68

24개 VM(부서 단말 12대 포함), 내장 스위치 8개입니다. 모든 VM은 정지 상태로 준비합니다.
원본 8종은 복제 원본으로만 사용합니다. 기존 프로젝트 VM을 직접 연결하거나 연결 복제를 하지 않습니다.

## PC에서 실행 순서

1. ZIP을 짧은 로컬 경로(예: C:\CampusXDR\CXDR-bead2c68)에 모두 압축 해제합니다.
2. Python 3.10 이상, VirtualBox, 로컬 GNS3 v2와 내장 스위치용 Dynamips가 있어야 합니다.
   GNS3 VM 내부가 아니라 VirtualBox VM이 등록된 같은 사용자 계정의 PC GNS3 서버를 사용합니다.
3. 복제 원본은 정상 종료해 주세요. 실행 중/저장 상태면 스크립트가 중단합니다. 자동으로 원본 전원을 끄지 않습니다.
4. `setup.bat`을 더블클릭합니다. 원본을 정확한 이름으로 검색하고, 중복·이름 충돌·디스크 부족을 검사한 뒤
   새 이름/UUID/독립 디스크의 완전 복제본 24개를 만듭니다. 수십~수백 GB가 필요할 수 있으며 실제 원본
   가상 디스크 용량으로 사전 계산합니다. VM은 부팅하지 않고 복제본 NIC는 우선 격리/연결 해제합니다.
5. `clone-audit.json`의 complete=true를 확인한 다음 `CXDR-bead2c68-Campus-XDR.gns3`를 GNS3에서 엽니다.
   새 복제본 이름만 참조합니다. 원본 VM 이름으로 노드 속성을 바꾸지 마세요.
6. 아래 게스트 설정을 적용한 뒤 필요한 장비만 켭니다. GNS3의 전체 시작 버튼은 사용하지 마세요.

원본을 검사만 하려면 `py -3 prepare_virtualbox.py --check`를 실행합니다.
VirtualBox 경로가 자동 검색되지 않으면 `--vboxmanage "C:\Program Files\Oracle\VirtualBox\VBoxManage.exe"`를 지정합니다.
원본 표시 이름이 목록과 다르면 `campus-manifest.json`의 bases 별칭만 정확하게 수정하고 다시 검사합니다.
이미 존재하는 복제본은 같은 패키지의 것이라도 자동 재사용하거나 삭제하지 않습니다. 중간 실패 시 복제본은
진단용으로 남기며, clone-audit.json을 확인하고 본인이 새로 만든 것만 정리한 뒤 재시도하세요.

## 반드시 알아야 할 현재 상태

이 클라우드는 PC의 VirtualBox에 접근할 수 없으므로 실제 복제/부팅/통신은 아직 실행하지 않았습니다.
.gns3 파일은 배선과 새 VM 참조를 담으며 OS·네트워크 설정이나 장비 이미지를 자동 포함하지 않습니다.
원본이 없는 상태에서 파일만 열면 VM을 찾을 수 없다는 오류가 나는 것이 정상입니다.
실제 PC에서 setup.bat을 먼저 실행해야 합니다. clonevm 동작은 VirtualBox 권한/원본 디스크/버전에 의존합니다.

## 게스트 설정 (복제본에만 적용)

- inventory.csv: 원본/역할/새 VM 이름. memory_mb는 권장 메모리이며 원본 또는 복제본의 메모리를 자동 변경하지 않습니다.
- address-plan.csv: NIC 번호, VLAN, 주소. GNS3 adapter 0은 VirtualBox NIC 1입니다.
- Linux: 새 호스트명과 고유 machine-id를 준비합니다. Windows도 호스트명/필요한 Sysprep을 별도로 수행합니다.
  완전 복제로 VirtualBox UUID/MAC/디스크는 달라져도 Windows SID와 OS 내부 ID가 자동 초기화되지는 않습니다.
- CORE1/2: Ubuntu24에 FRRouting/keepalived 설치, configs의 IF0~IF3를 실제 NIC명으로 치환합니다.
- DIST-A/B: Ubuntu22에 FRRouting 설치. NIC 3(IF2)는 802.1Q 트렁크입니다. VLAN 서브인터페이스 .10/.20/.30
  또는 .40/.50/.60을 먼저 만들고 주소를 지정합니다. IPv4 forwarding을 활성화합니다.
- FW1/2: pfSense NIC 순서는 WAN/LAN/SYNC/DMZ. 실제 주소는 CSV에 있습니다.
  CARP VIP: WAN 198.18.0.1, LAN 172.20.0.1, DMZ 10.90.0.1. FW1 우선, FW2 대기.
  SYNC 전용 인터페이스에서 pfsync/XMLRPC와 필요한 CARP 규칙을 설정합니다. 비밀값은 PC에서 직접 설정하세요.
  캠퍼스 경로 10.10.0.0/16, 10.20.0.0/16, 10.80.0.0/24의 next-hop은 CORE VIP 172.20.0.10입니다.
  실습 WAN은 사설 테스트망이므로 pfSense의 WAN private/bogon 차단 설정을 실습 주소에 맞게 검토합니다.
  WAN-LAB에는 호스트 브리지나 NAT가 없습니다. 외부 인터넷이 아닙니다.
- 기본 권장 정책: 외부→DMZ 웹만 허용, 외부→내부 차단, 게스트→내부 차단, IT→관리만 선택 허용.
  부서 간 트래픽은 배포/코어에서 라우팅되므로 경계 pfSense를 지나지 않습니다. 배포 장비의 ACL/nftables도
  설정해야 동서 트래픽을 제어할 수 있습니다. 이 패키지는 적용 전 정책이나 장애 전환을 검증했다고 주장하지 않습니다.
- WEB-DMZ: 웹 서비스 설치. APP-INTERNAL: SSH/auth 로그 발생 서비스.
- XDR-COLLECTOR: 수집기용 VM 자리/주소만 준비했습니다. 기존 Docker용 소규모 에이전트는 이 캠퍼스에
  자동 설치되지 않으며, 여러 로그 출처와 주소 대역을 지원하도록 별도 연결/확장이 필요합니다.
- LEGACY-WIN7/SOPHOS-SANDBOX는 완전히 별도 세그먼트이며 캠퍼스/실습 WAN과 연결되지 않습니다.
  Sophos는 pfSense와 HA를 구성하지 않습니다. Sophos WAN NIC 1은 의도적으로 미연결입니다.

## 필요한 것만 켜기

- 최소 A동: FW1, CORE1, DIST-A, XDR-COLLECTOR, WEB-DMZ, STUDENT-02 (6 VM).
- 부서별 1대: manifest.profiles.campus-one-per-department 참고. 각 부서 -02(Linux)부터 사용합니다.
- 이중화: FW2/CORE2까지 켜고 CARP/VRRP/OSPF를 적용/검사합니다. 건물별 배포 장비는 단일 장애점입니다.
- 단말 -01/02는 모두 만들어 두되, 필요할 때 GNS3에서 한 대씩 시작합니다. 전송 경로의 장비는 함께 켜야 합니다.
- 최소 프로필 권장 RAM 합계는 약 8GB이며 OS/하이퍼바이저 여유가 별도 필요합니다. 전체 동시 기동을 권장하지 않습니다.

.gns3를 다른 프로젝트용으로 복사해 같은 복제본을 공유하지 마세요. 새 실습망에는 새 UUID/접두사로 만든
별도 패키지가 필요합니다. 이 패키지의 setup은 다른 GNS3 파일을 읽거나 수정하지 않고 기존 VM을 재사용하지 않습니다.
