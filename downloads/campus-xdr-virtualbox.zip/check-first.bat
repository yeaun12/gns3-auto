@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python prepare_virtualbox.py --check) else (py -3 prepare_virtualbox.py --check)
echo.
pause
