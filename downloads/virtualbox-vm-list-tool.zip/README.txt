VirtualBox VM list collector (READ ONLY)

1. Extract all files into a local folder.
2. Double-click collect-vms.bat using the same Windows account that normally runs VirtualBox.
3. A new vm-inventory-<time>-<id> folder contains vm-inventory.json, vm-list.csv and vm-list.txt.
4. Share vm-inventory.json (preferred) or vm-list.txt in the chat. There is no automatic upload.

Python 3.10+ and the existing VirtualBox installation are required. No extra packages or administrator access are needed.
The tool only calls list vms, showvminfo and showmediuminfo. It does NOT clone, start, stop, register, delete or modify any VM.
It reports all registered VM names/UUIDs, power state, RAM/OS metadata and virtual disk parent dependencies.
Uninspectable VMs are retained and marked partial instead of silently skipped.
A standalone disk does not prove original-vs-full-clone history. GNS3 project usage cannot be inferred from this inventory.
Credentials, full host file paths and guest/disk file contents are not included in the exported JSON/CSV/text.
The .vbox settings file is read locally only to identify current hard disk UUIDs.

Window closure after pressing a key is normal. Results and the scan log remain in the extracted folder.
A PowerShell fallback requiring no download is:
& "$env:ProgramFiles\Oracle\VirtualBox\VBoxManage.exe" list vms | Out-File "$env:USERPROFILE\Desktop\vm-list.txt" -Encoding utf8
That fallback exports names/UUIDs only, without detailed disk/state checks.

Six inventory tests and the full 50-test development suite passed. Actual execution on your PC remains to be checked.
