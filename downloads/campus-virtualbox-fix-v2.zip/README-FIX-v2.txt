VirtualBox showmediuminfo compatibility fix (v2)

1. Close the stopped check window. That failure occurred before cloning or starting any VM.
2. Copy prepare_virtualbox.py and check-first.bat into the original extracted campus folder.
   Replace only these two tool files. Keep campus-manifest.json, .gns3 and any existing VM files.
3. Run check-first.bat again. It now writes check-result.txt so the result survives window closure.
4. CHECK PASSED means source/name/state/disk checks passed; it does not clone or start VMs.
5. If STOP appears, send check-result.txt. Do not delete or change base VMs.

The --machinereadable option remains on showvminfo, where it is supported.
It has been removed specifically from showmediuminfo; standard UUID/Parent UUID/Location/Capacity fields are validated instead.
44 automated tests passed. This was not executed against the user's real VirtualBox installation.
