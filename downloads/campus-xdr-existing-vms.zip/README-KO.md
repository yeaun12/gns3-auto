# 기존 VirtualBox 복제본을 재사용하는 캠퍼스 XDR

## 시작 순서

1. 이 ZIP을 기존 복제용 패키지와 다른 새 폴더에 압축 해제합니다.
2. `role-mapping.csv`에서 장비 역할과 실제 VirtualBox 이름을 확인합니다. 원본 8종은 선택하지 않았습니다.
3. 선택한 VM을 정상 종료한 상태에서 `check-existing-vms.bat`을 실행합니다. 조회만 하며 결과는 reuse-check-result.txt에 남습니다.
4. CHECK PASSED 후 `Campus-XDR-existing.gns3`를 PC의 로컬 GNS3 v2 서버에서 엽니다. VirtualBox와 같은 사용자 계정을 사용합니다.
5. 모든 VM 자동 시작은 꺼져 있습니다. 필요한 프로필의 노드만 한 대씩 시작하세요. 전체 시작은 피하세요.

이 패키지에는 setup.bat, clonevm, snapshot 생성이나 VM 삭제 기능이 없습니다. 이전 패키지의 setup.bat은 실행하지 마세요.
.gns3에는 선택된 기존 VM 이름과 linked_clone=false를 지정했습니다. 새 VM이나 전체 디스크 복제를 만들지 않습니다.
GNS3에서 시작하면 선택된 복제본의 NIC 구성은 변경될 수 있습니다. 그 VM의 이전 IP/서비스/보안 설정은 그대로 남아 있습니다.
따라서 역할에 맞는 설정이 필요하며 다른 GNS3 프로젝트와 동시에 같은 VM을 공유하지 마세요.

## 구성과 자원

- 기존 VM 26대, 내장 스위치 9대, 링크 41개. 부서별 단말은 2대씩, 총 12대입니다.
- 가장 작은 A동 프로필: FW1, CORE1, DIST-A, XDR-COLLECTOR, WEB-DMZ, STUDENT-02, ZEEK-SENSOR, SURICATA-SENSOR.
  현재 목록 기준 VM 메모리 합계 16GiB입니다. 호스트/GNS3 여유가 별도로 필요합니다.
- 부서별 1대/코어·방화벽 이중화 후보 프로필은 campus-bindings.json의 profiles에 있습니다.
- 기존 디스크를 재사용하므로 24개 완전 복제 공간 검사는 없습니다. VM 쓰기/업데이트/로그에 따른 디스크 증가는 여전히 발생합니다.
- VM 이름은 바꾸지 않습니다. GNS3의 CORE1 등의 역할 이름과 VirtualBox의 기존 이름은 다를 수 있습니다.

## 디스크 의존 관계

수집 시점에는 선택된 모든 VM이 꺼져 있고 디스크 부모 체인을 읽을 수 있었습니다. 일부 Windows/Sophos/Kali는
기존 스냅샷/부모 디스크에 의존합니다. 오래된 .gns3 파일을 지웠더라도 VirtualBox 원본/스냅샷/가상 디스크는
임의로 삭제하거나 이동하지 마세요. 기존 VM이 원본인지 완전 복제본인지 디스크 정보만으로 확정하지 않습니다.
검사 도구는 등록 이름/UUID/디스크 체인을 다시 확인하지만 다른 GNS3 파일의 사용 여부까지 확정하지는 않습니다.

## 네트워크와 센서 설정 — 아직 적용/실행 검증되지 않음

- 주소와 NIC 순서는 address-plan.csv에 있습니다. GNS3 adapter 0은 VirtualBox NIC 1입니다.
- CORE/DIST는 기존 RockyLinux VM입니다. /etc/os-release와 NIC 이름을 확인한 뒤 Rocky용 FRRouting과
  keepalived를 설치/설정해야 합니다. configs의 IF0~IF3를 실제 NIC 이름으로 치환합니다.
- CORE1/2 VRRP: edge 172.20.0.10(IF0), server 10.80.0.1(IF3), 우선순위 150/100. IPv4 forwarding 활성화.
- DIST-A/B의 3번째 NIC는 VLAN 트렁크입니다. A동은 VLAN 10/20/30, B동은 40/50/60 서브인터페이스를 만듭니다.
- FW1/FW2는 둘 다 Sophos UTM 복제본입니다. NIC 순서는 WAN/LAN/HA-SYNC/DMZ입니다. 서비스 주소는
  WAN 198.18.0.1, LAN 172.20.0.1, DMZ 10.90.0.1입니다. 이것은 Sophos 클러스터용 계획이며 pfSense CARP 설정이 아닙니다.
  HA 구성/호환 버전/라이선스 확인 전에는 FW1만 사용하고 FW2는 꺼 두세요. 두 독립 장비에 같은 서비스 IP를
  지정하고 동시에 시작하면 충돌합니다. 게스트의 기존 설정과 실제 HA 상태는 아직 확인하지 않았습니다.
- 방화벽의 내부 경로는 10.10.0.0/16, 10.20.0.0/16, 10.80.0.0/24 → 172.20.0.10입니다.
- Zeek는 FW-SIDE와 CORE-TRANSIT 사이, Suricata는 DMZ-SW와 WEB-DMZ 사이에 인라인으로 연결됩니다.
  센서 NIC 1/2를 IP 없는 투명 브리지로 설정하고, NIC 3은 서버망 관리용으로 사용합니다. 데이터 NIC로 DHCP를 받지 마세요.
  센서를 끄거나 브리지를 구성하지 않으면 해당 통신 경로가 끊깁니다. 이 구조는 스위치 미러링이 아닙니다.
- Zeek/Suricata가 설치/실행 중이라고 VM 이름만 보고 가정하지 않습니다. 실제 패키지와 캡처 인터페이스를 확인하세요.
  Suricata VM의 VirtualBox OS 유형은 Ubuntu22.10으로 수집됐지만 실제 OS 버전은 게스트 /etc/os-release로 확인해야 합니다.
- WEB-DMZ, APP-INTERNAL 서비스도 이름만으로 설치 여부를 확정하지 않습니다. 기존 데이터/설정을 지우지 말고 필요한 서비스만 조정하세요.
- XDR 수집기 자리는 준비했지만 기존 Docker 전용 보안 에이전트가 여기에 자동 배포되지는 않습니다.
  센서·인증 로그 전달 및 캠퍼스 주소 대역 대응을 추가 구현해야 합니다.
- 부서 간 라우팅은 배포/코어에서 이루어집니다. 경계 방화벽만으로 동서 트래픽이 차단되지 않으므로 배포 ACL도 필요합니다.
- Kali 쪽은 격리된 WAN 테스트망으로 호스트 브리지/NAT/Cloud 연결이 없습니다. GNS3 바깥에서 VM을 직접 시작하면 이전 NIC 설정이 사용될 수 있으므로 GNS3에서 시작하세요.
- Windows7과 pfSense 복제본은 별도 격리 실습 구역입니다. 캠퍼스나 외부망으로 이어지는 링크가 없습니다.

배선/파일 형식 검증과 실제 PC에서의 부팅/통신/XDR 검증은 다릅니다. 이 패키지는 실제 PC 실행이 완료됐다고 주장하지 않습니다.
