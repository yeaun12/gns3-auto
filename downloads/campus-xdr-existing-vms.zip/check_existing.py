"""Read-only checker for a campus bound to existing VirtualBox VMs."""
import argparse
import json
from pathlib import Path
import sys
import subprocess
import xml.etree.ElementTree as ET
import uuid

if __package__:
    from .vbox_inventory import ReadOnlyVBox, parse_inventory, machine_fields, disk_ids, medium_fields
else:
    from collect_virtualbox import ReadOnlyVBox, parse_inventory, machine_fields, disk_ids, medium_fields


def check(directory,vbox):
    directory=Path(directory)
    plan=json.loads((directory/'campus-bindings.json').read_text(encoding='utf-8'))
    if plan.get('mode')!='reuse-existing-vms':raise ValueError('Not an existing-VM package')
    document=json.loads((directory/'Campus-XDR-existing.gns3').read_text(encoding='utf-8'))
    if document['project_id']!=plan['project_id'] or document.get('auto_start') is not False:raise ValueError('Project identity/startup mismatch')
    bindings=plan['bindings'];ids=[b['vm_uuid'] for b in bindings];names=[b['vm_name'] for b in bindings]
    if len(ids)!=len(set(ids)) or len(names)!=len(set(names)):raise ValueError('VM allocated more than once')
    if set(names)&set(plan['original_bases_excluded']):raise ValueError('An original base was selected')
    nodes=[n for n in document['topology']['nodes'] if n['node_type']=='virtualbox']
    roles={b['role']:b for b in bindings}
    if len(nodes)!=len(bindings):raise ValueError('VM membership mismatch')
    for node in nodes:
        expected=roles[node['name']]
        if node['properties']['vmname']!=expected['vm_name'] or node['properties'].get('linked_clone') is not False:
            raise ValueError('Project must reference exactly the allocated existing VM')
    registered={item['uuid']:item['name'] for item in parse_inventory(vbox.run('list','vms'))}
    failures=[];cache={}
    def disk(identity):
        if identity not in cache:cache[identity]=medium_fields(vbox.run('showmediuminfo','disk',identity),identity)
        if cache[identity].get('state')!='created':raise ValueError('Virtual disk is inaccessible or not in a usable state')
        return cache[identity]
    for binding in bindings:
        try:
            identity=str(uuid.UUID(binding['vm_uuid']))
            if registered.get(identity)!=binding['vm_name']:raise ValueError('Registered name/UUID changed')
            info=machine_fields(vbox.run('showvminfo',identity,'--machinereadable'))
            if info.get('VMState')!='poweroff':raise ValueError('VM must be normally shut down')
            current=set(disk_ids(info['CfgFile']))
            if current!={d['uuid'] for d in binding['disks']}:raise ValueError('Current disks changed; collect a new inventory')
            for expected in binding['disks']:
                actual=disk(expected['uuid']);parents=[];seen={expected['uuid']}
                while actual['parent_uuid']:
                    parent=actual['parent_uuid']
                    if parent in seen or len(seen)>64:raise ValueError('Invalid parent chain')
                    seen.add(parent);parents.append(parent);actual=disk(parent)
                if parents!=expected['parent_chain']:raise ValueError('Disk dependency chain changed')
            print('OK: '+binding['role']+' -> '+binding['vm_name'],flush=True)
        except (RuntimeError,ValueError,KeyError,OSError,ET.ParseError,subprocess.TimeoutExpired) as exc:
            failures.append(binding['role']+': '+str(exc));print('STOP: '+failures[-1],flush=True)
    if failures:raise RuntimeError(str(len(failures))+' selected VMs require review; no changes made.')
    print('CHECK PASSED: existing names, UUIDs, power-off state and disk chains match.',flush=True)
    print('No VM was cloned, started, stopped, renamed or modified. Guest networking/HA/XDR is not verified.',flush=True)
    return True


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',default=str(Path(__file__).resolve().parent));parser.add_argument('--vboxmanage')
    args=parser.parse_args()
    try:check(args.directory,ReadOnlyVBox(args.vboxmanage));return 0
    except (RuntimeError,ValueError,OSError,KeyError,ET.ParseError,subprocess.TimeoutExpired) as exc:print('STOP: '+str(exc),file=sys.stderr);return 1


if __name__=='__main__':raise SystemExit(main())
