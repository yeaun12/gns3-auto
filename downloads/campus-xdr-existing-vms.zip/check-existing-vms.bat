@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python check_existing.py > reuse-check-result.txt 2>&1) else (py -3 check_existing.py > reuse-check-result.txt 2>&1)
set "reuse_check_exit=%errorlevel%"
type reuse-check-result.txt
echo.
echo Results saved in reuse-check-result.txt
pause
exit /b %reuse_check_exit%
